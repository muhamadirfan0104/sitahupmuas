package muhamad.irfan.sitahupm.ui.cart

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.model.CartItem
import muhamad.irfan.sitahupm.ui.checkout.CheckoutActivity
import muhamad.irfan.sitahupm.ui.common.SimpleCard
import muhamad.irfan.sitahupm.ui.common.SimpleCardAdapter
import muhamad.irfan.sitahupm.ui.main.MainActivity
import muhamad.irfan.sitahupm.util.FormatUtil
import org.json.JSONObject

class CartFragment : Fragment() {
    private lateinit var adapter: SimpleCardAdapter
    private lateinit var txtTotal: TextView
    private var totalBelanja = 0.0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_cart, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        txtTotal = view.findViewById(R.id.txtCartTotal)
        adapter = SimpleCardAdapter(mutableListOf(), { updateQty(it, 1) }, { updateQty(it, -1) })
        view.findViewById<RecyclerView>(R.id.rvCart).apply {
            layoutManager = LinearLayoutManager(view.context)
            adapter = this@CartFragment.adapter
        }
        view.findViewById<View>(R.id.btnContinueShop).setOnClickListener {
            (activity as? MainActivity)?.openProductsFromHome()
        }
        view.findViewById<View>(R.id.btnCheckout).setOnClickListener {
            val ctx = context ?: return@setOnClickListener
            startActivity(Intent(ctx, CheckoutActivity::class.java))
        }
        load()
    }

    private fun load() {
        val ctx = context ?: return
        ApiClient.request(ctx, Request.Method.GET, "/cart", null, { response ->
            if (isAdded && view != null) {
                val data = response.getJSONObject("data")
                val arr = data.getJSONArray("items")
                val list = mutableListOf<SimpleCard>()
                for (i in 0 until arr.length()) {
                    val cart = CartItem.fromJson(arr.getJSONObject(i))
                    list.add(
                        SimpleCard(
                            top = cart.nama,
                            mid = "${cart.jumlah} x ${FormatUtil.rupiah(cart.harga)}\nStok ${cart.stok}",
                            bottom = "Subtotal ${FormatUtil.rupiah(cart.subtotal)}",
                            primary = "+",
                            second = "−",
                            dataId = cart.id
                        )
                    )
                }
                totalBelanja = data.optDouble("total_belanja")
                txtTotal.text = "Total: ${FormatUtil.rupiah(totalBelanja)}"
                if (list.isEmpty()) {
                    adapter.setItems(listOf(SimpleCard("Keranjang kosong", "Pilih produk dulu untuk checkout.", "", "Refresh", "Produk", 0)))
                } else {
                    adapter.setItems(list)
                }
            }
        }, {
            if (isAdded) toast(it)
        })
    }

    private fun updateQty(card: SimpleCard, delta: Int) {
        if (card.dataId == 0) {
            load()
            return
        }
        val ctx = context ?: return
        val current = Regex("^(\\d+)").find(card.mid)?.groupValues?.get(1)?.toIntOrNull() ?: 1
        val qty = (current + delta).coerceAtLeast(1)
        ApiClient.request(ctx, Request.Method.PATCH, "/cart/items/${card.dataId}", JSONObject().put("jumlah", qty), {
            if (isAdded) load()
        }, {
            if (isAdded) toast(it)
        })
    }

    private fun toast(message: String) {
        val ctx = context ?: return
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        if (::adapter.isInitialized) load()
    }
}
