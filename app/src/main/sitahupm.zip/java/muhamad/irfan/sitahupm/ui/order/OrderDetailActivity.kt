package muhamad.irfan.sitahupm.ui.order

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.model.Order
import muhamad.irfan.sitahupm.util.FormatUtil
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder

class OrderDetailActivity: AppCompatActivity() {
    private var orderId=0; private var order: Order?=null
    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r -> if(r.resultCode== Activity.RESULT_OK){ r.data?.data?.let { upload(it) } } }
    private val camera = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r -> if(r.resultCode== Activity.RESULT_OK){ val bmp = r.data?.extras?.get("data") as? Bitmap; bmp?.let { upload(saveBitmap(it)) } } }
    override fun onCreate(b:Bundle?){ super.onCreate(b); setContentView(R.layout.activity_detail); orderId=intent.getIntExtra("id",0); findViewById<Button>(R.id.btnSecond).text="Kamera/Pilih Bukti"; findViewById<Button>(R.id.btnSecond).setOnClickListener{ chooseProof() }; findViewById<Button>(R.id.btnPrimary).text="Buka Invoice"; findViewById<Button>(R.id.btnPrimary).setOnClickListener{ openInvoice() }; load() }
    private fun load(){ ApiClient.request(this, Request.Method.GET, "/orders/$orderId", null, { r -> order=Order.fromJson(r.getJSONObject("data")); val o=order!!; findViewById<TextView>(R.id.txtTitle).text=o.invoice; findViewById<TextView>(R.id.txtInfo).text="Status: ${o.status}\nPembayaran: ${o.statusBayar}\nMetode: ${o.metodeAmbil} - ${o.metodeBayar}\nTotal: ${FormatUtil.rupiah(o.total)}\nQR Token: ${o.qrToken ?: "-"}\n\nUntuk ambil di toko, tunjukkan QR ini ke admin."; showQr(o) }, { toast(it) }) }
    private fun showQr(o:Order){ if(o.qrToken.isNullOrBlank()) return; val web=findViewById<WebView>(R.id.webView); web.visibility= View.VISIBLE; val data=URLEncoder.encode(o.qrUrl ?: o.qrToken, "UTF-8"); web.loadUrl("https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=$data") }
    private fun chooseProof(){ val menu=androidx.appcompat.widget.PopupMenu(this, findViewById(R.id.btnSecond)); menu.menu.add("Ambil dari Kamera"); menu.menu.add("Pilih dari Galeri"); menu.setOnMenuItemClickListener { if(it.title.toString().contains("Kamera")) camera.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) else pickImage(); true }; menu.show() }
    private fun pickImage(){ val intent=Intent(Intent.ACTION_GET_CONTENT).setType("image/*"); picker.launch(Intent.createChooser(intent,"Pilih bukti transfer")) }
    private fun saveBitmap(bitmap: Bitmap): Uri { val file=File(cacheDir, "bukti_kamera_${System.currentTimeMillis()}.jpg"); FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out) }; return Uri.fromFile(file) }
    private fun upload(uri:Uri){ ApiClient.uploadFile(this, "/orders/$orderId/payment-proof", "bukti_transfer", uri, { toast("Bukti transfer berhasil diupload"); load() }, { toast(it) }) }
    private fun openInvoice(){ order?.invoiceUrl?.let { findViewById<WebView>(R.id.webView).apply { visibility=View.VISIBLE; settings.javaScriptEnabled=false; loadUrl(it) } } ?: toast("Invoice belum tersedia") }
    private fun toast(m:String)= Toast.makeText(this,m,Toast.LENGTH_LONG).show()
}
