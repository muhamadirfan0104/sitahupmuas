package muhamad.irfan.sitahupm.ui.order

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.model.Order
import muhamad.irfan.sitahupm.ui.common.SimpleCard
import muhamad.irfan.sitahupm.ui.common.SimpleCardAdapter
import muhamad.irfan.sitahupm.util.FormatUtil

class OrdersFragment : Fragment() {
    private lateinit var adapter: SimpleCardAdapter
    private lateinit var filterRow: LinearLayout
    private val orders = mutableListOf<Order>()
    private var activeFilter = "Semua"
    private val filters = listOf("Semua", "Belum Bayar", "Dikemas", "Dikirim", "Selesai", "Batal")

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_orders, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        filterRow = view.findViewById(R.id.filterRow)
        adapter = SimpleCardAdapter(mutableListOf(), { open(it.dataId) }, { open(it.dataId) })
        view.findViewById<RecyclerView>(R.id.rvOrders).apply {
            layoutManager = LinearLayoutManager(view.context)
            adapter = this@OrdersFragment.adapter
        }
        view.findViewById<View>(R.id.btnRefreshOrders).setOnClickListener { load() }
        renderFilters()
        load()
    }

    private fun renderFilters() {
        if (!isAdded || !::filterRow.isInitialized) return
        val ctx = context ?: return
        filterRow.removeAllViews()
        filters.forEach { label ->
            val btn = Button(ctx)
            btn.text = label
            btn.textSize = 12f
            btn.isAllCaps = false
            btn.setTextColor(resources.getColor(if (label == activeFilter) R.color.primary else R.color.text_muted, null))
            btn.setBackgroundResource(if (label == activeFilter) R.drawable.bg_tag else R.drawable.bg_card)
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 38.dp())
            lp.setMargins(0, 0, 8.dp(), 0)
            btn.layoutParams = lp
            btn.setOnClickListener {
                activeFilter = label
                renderFilters()
                renderOrders()
            }
            filterRow.addView(btn)
        }
    }

    private fun load() {
        val ctx = context ?: return
        ApiClient.request(ctx, Request.Method.GET, "/orders", null, { response ->
            if (isAdded && view != null) {
                val arr = response.getJSONObject("data").getJSONArray("data")
                orders.clear()
                for (i in 0 until arr.length()) orders.add(Order.fromJson(arr.getJSONObject(i)))
                renderOrders()
            }
        }, {
            if (isAdded) toast(it)
        })
    }

    private fun renderOrders() {
        if (!::adapter.isInitialized) return
        val filtered = orders.filter { matchFilter(it) }
        if (filtered.isEmpty()) {
            adapter.setItems(listOf(SimpleCard("Belum ada pesanan", "Pesanan dengan filter ini belum tersedia.", "Silakan belanja dulu", "Refresh", "Produk", 0)))
            return
        }
        adapter.setItems(filtered.map { order ->
            SimpleCard(
                top = order.invoice,
                mid = "Pesanan: ${order.status}\nBayar: ${order.statusBayar}\n${order.metodeAmbil} • ${order.metodeBayar}",
                bottom = FormatUtil.rupiah(order.total),
                primary = "Detail",
                second = "QR / Upload",
                dataId = order.id
            )
        })
    }

    private fun matchFilter(order: Order): Boolean = when (activeFilter) {
        "Belum Bayar" -> order.statusBayar.contains("belum", true) || order.statusBayar.contains("verifikasi", true)
        "Dikemas" -> order.status.contains("kemas", true) || order.status.contains("proses", true) || order.status.contains("konfirmasi", true)
        "Dikirim" -> order.status.contains("kirim", true)
        "Selesai" -> order.status.contains("selesai", true)
        "Batal" -> order.status.contains("batal", true) || order.status.contains("tolak", true)
        else -> true
    }

    private fun open(id: Int) {
        if (id == 0) {
            load()
            return
        }
        val ctx = context ?: return
        startActivity(Intent(ctx, OrderDetailActivity::class.java).putExtra("id", id))
    }

    private fun toast(message: String) {
        val ctx = context ?: return
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        if (::adapter.isInitialized) load()
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()
}
