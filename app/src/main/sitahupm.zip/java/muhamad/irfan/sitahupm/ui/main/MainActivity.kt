package muhamad.irfan.sitahupm.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.local.SessionManager
import muhamad.irfan.sitahupm.ui.auth.AuthActivity
import muhamad.irfan.sitahupm.ui.cart.CartFragment
import muhamad.irfan.sitahupm.ui.home.HomeFragment
import muhamad.irfan.sitahupm.ui.order.OrdersFragment
import muhamad.irfan.sitahupm.ui.product.ProductsFragment
import muhamad.irfan.sitahupm.ui.profile.ProfileFragment

class MainActivity : AppCompatActivity() {
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var headerNormal: View
    private lateinit var headerSearch: View
    private lateinit var headerLogo: TextView
    private lateinit var title: TextView
    private lateinit var btnBack: TextView
    private lateinit var btnTopSearch: ImageButton
    private lateinit var btnDots: TextView
    private lateinit var edtSearch: EditText
    private var currentTab: Int = R.id.nav_home
    private var inSearchMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!SessionManager(this).isLogin()) {
            startActivity(Intent(this, AuthActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_main)
        bindHeader()
        bindBottomNav()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = handleBack()
        })
        if (savedInstanceState == null) openTab(R.id.nav_home)
    }

    private fun bindHeader() {
        headerNormal = findViewById(R.id.headerNormal)
        headerSearch = findViewById(R.id.headerSearch)
        headerLogo = findViewById(R.id.headerLogo)
        title = findViewById(R.id.txtHeaderTitle)
        btnBack = findViewById(R.id.btnBack)
        btnTopSearch = findViewById(R.id.btnTopSearch)
        btnDots = findViewById(R.id.btnDots)
        edtSearch = findViewById(R.id.edtTopSearch)
        val btnSearchBack: TextView = findViewById(R.id.btnSearchBack)
        val btnSubmit: Button = findViewById(R.id.btnSubmitSearch)

        btnBack.setOnClickListener { handleBack() }
        btnSearchBack.setOnClickListener { handleBack() }
        btnTopSearch.setOnClickListener { openSearchPage() }
        btnDots.setOnClickListener { showMenu(it) }
        btnSubmit.setOnClickListener { submitSearch() }
        edtSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { submitSearch(); true } else false
        }
    }

    private fun bindBottomNav() {
        bottomNav = findViewById(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            openTab(item.itemId)
            true
        }
    }

    private fun openTab(id: Int) {
        currentTab = id
        val fragment: Fragment
        val pageTitle: String
        when (id) {
            R.id.nav_products -> { fragment = ProductsFragment.newInstance(searchMode = false); pageTitle = "Produk" }
            R.id.nav_cart -> { fragment = CartFragment(); pageTitle = "Keranjang" }
            R.id.nav_orders -> { fragment = OrdersFragment(); pageTitle = "SiTahu" }
            R.id.nav_profile -> { fragment = ProfileFragment(); pageTitle = "Profil" }
            else -> { fragment = HomeFragment(); pageTitle = "SiTahu"; currentTab = R.id.nav_home }
        }
        replace(fragment, pageTitle, searchMode = false, addBack = false)
    }

    fun openProductsFromHome() {
        bottomNav.selectedItemId = R.id.nav_products
    }

    private fun openSearchPage() {
        currentTab = R.id.nav_products
        bottomNav.menu.findItem(R.id.nav_products).isChecked = true
        replace(ProductsFragment.newInstance(searchMode = true), "Pencarian Produk", searchMode = true, addBack = true)
        edtSearch.setText("")
        edtSearch.requestFocus()
    }

    private fun submitSearch() {
        val q = edtSearch.text.toString().trim()
        (supportFragmentManager.findFragmentById(R.id.frameContent) as? SearchReceiver)?.onSearchSubmit(q)
    }

    private fun replace(fragment: Fragment, pageTitle: String, searchMode: Boolean, addBack: Boolean) {
        inSearchMode = searchMode
        title.text = pageTitle
        val tx = supportFragmentManager.beginTransaction().replace(R.id.frameContent, fragment)
        if (addBack) tx.addToBackStack(pageTitle)
        else supportFragmentManager.popBackStack(null, androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE)
        tx.commit()
        updateHeader(pageTitle, searchMode)
    }

    private fun updateHeader(pageTitle: String, searchMode: Boolean) {
        headerNormal.visibility = if (searchMode) View.GONE else View.VISIBLE
        headerSearch.visibility = if (searchMode) View.VISIBLE else View.GONE
        title.text = pageTitle
        val isMainTab = currentTab in listOf(R.id.nav_home, R.id.nav_products, R.id.nav_cart, R.id.nav_orders, R.id.nav_profile)
        btnBack.visibility = if (!isMainTab || supportFragmentManager.backStackEntryCount > 0) View.VISIBLE else View.GONE
        headerLogo.visibility = if (btnBack.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        btnTopSearch.visibility = if (!searchMode && (currentTab == R.id.nav_home || currentTab == R.id.nav_products)) View.VISIBLE else View.GONE
        btnDots.visibility = if (searchMode) View.GONE else View.VISIBLE
    }

    private fun showMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add("Refresh halaman")
        menu.menu.add("Tentang SiTahu")
        menu.setOnMenuItemClickListener {
            Toast.makeText(this, it.title, Toast.LENGTH_SHORT).show()
            true
        }
        menu.show()
    }

    private fun handleBack() {
        if (inSearchMode || supportFragmentManager.backStackEntryCount > 0) {
            supportFragmentManager.popBackStack()
            inSearchMode = false
            when (currentTab) {
                R.id.nav_products -> updateHeader("Produk", false)
                R.id.nav_home -> updateHeader("SiTahu", false)
                R.id.nav_cart -> updateHeader("Keranjang", false)
                R.id.nav_orders -> updateHeader("SiTahu", false)
                R.id.nav_profile -> updateHeader("Profil", false)
            }
        } else finish()
    }
}
