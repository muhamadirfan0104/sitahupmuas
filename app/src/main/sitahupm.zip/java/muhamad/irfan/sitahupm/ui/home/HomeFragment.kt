package muhamad.irfan.sitahupm.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.model.Product
import muhamad.irfan.sitahupm.ui.main.MainActivity
import muhamad.irfan.sitahupm.ui.product.ProductAdapter
import muhamad.irfan.sitahupm.ui.product.ProductDetailActivity
import org.json.JSONObject

class HomeFragment : Fragment() {
    private lateinit var adapter: ProductAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = ProductAdapter(
            mutableListOf(),
            onAdd = { add(it.id) },
            onDetail = { p -> openDetail(p) },
            showLatestBadge = true
        )

        view.findViewById<RecyclerView>(R.id.rvHomeProducts).apply {
            layoutManager = GridLayoutManager(view.context, 2)
            adapter = this@HomeFragment.adapter
            isNestedScrollingEnabled = false
        }

        view.findViewById<View>(R.id.btnShopNow).setOnClickListener {
            (activity as? MainActivity)?.openProductsFromHome()
        }
        view.findViewById<TextView>(R.id.txtSeeAll).setOnClickListener {
            (activity as? MainActivity)?.openProductsFromHome()
        }
        load()
    }

    private fun load() {
        val ctx = context ?: return
        ApiClient.request(ctx, Request.Method.GET, "/products?per_page=4&sort=latest", null, { response ->
            if (isAdded && view != null) {
                val arr = response.getJSONObject("data").getJSONArray("data")
                val list = mutableListOf<Product>()
                for (i in 0 until arr.length()) list.add(Product.fromJson(arr.getJSONObject(i)))
                adapter.setItems(list)
            }
        }, { message ->
            if (isAdded) toast(message)
        })
    }

    private fun add(id: Int) {
        val ctx = context ?: return
        ApiClient.request(ctx, Request.Method.POST, "/cart/items", JSONObject().put("produk_id", id).put("jumlah", 1), {
            if (isAdded) toast("Produk masuk keranjang")
        }, {
            if (isAdded) toast(it)
        })
    }

    private fun openDetail(product: Product) {
        val ctx = context ?: return
        startActivity(Intent(ctx, ProductDetailActivity::class.java).putExtra("id", product.id))
    }

    private fun toast(message: String) {
        val ctx = context ?: return
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show()
    }
}
