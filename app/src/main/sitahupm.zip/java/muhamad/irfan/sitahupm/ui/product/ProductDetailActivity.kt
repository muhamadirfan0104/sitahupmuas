package muhamad.irfan.sitahupm.ui.product

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.model.Product
import muhamad.irfan.sitahupm.util.FormatUtil
import org.json.JSONObject

class ProductDetailActivity : AppCompatActivity() {
    private var productId = 0
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_detail); productId = intent.getIntExtra("id", 0); findViewById<Button>(R.id.btnSecond).setOnClickListener { finish() }; findViewById<Button>(R.id.btnPrimary).setOnClickListener { add() }; load() }
    private fun load(){ ApiClient.request(this, Request.Method.GET, "/products/$productId", null, { r -> val p=Product.fromJson(r.getJSONObject("data")); findViewById<TextView>(R.id.txtTitle).text=p.nama; findViewById<TextView>(R.id.txtInfo).text="${FormatUtil.rupiah(p.harga)}\nStok: ${p.stok} ${p.satuan}\n\n${p.deskripsi.ifBlank { "Deskripsi produk belum tersedia." }}"; ApiClient.loadImage(this, p.gambar, findViewById(R.id.imgMain)) }, { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }) }
    private fun add(){ ApiClient.request(this, Request.Method.POST, "/cart/items", JSONObject().put("produk_id", productId).put("jumlah", 1), { Toast.makeText(this, "Produk masuk keranjang", Toast.LENGTH_SHORT).show() }, { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }) }
}
