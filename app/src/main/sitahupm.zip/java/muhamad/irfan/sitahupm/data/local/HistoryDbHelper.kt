package muhamad.irfan.sitahupm.data.local

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class HistoryDbHelper(context: Context) : SQLiteOpenHelper(context, "sitahu_local.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) { db.execSQL("CREATE TABLE riwayat_pencarian(id INTEGER PRIMARY KEY AUTOINCREMENT, keyword TEXT, waktu INTEGER)") }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { db.execSQL("DROP TABLE IF EXISTS riwayat_pencarian"); onCreate(db) }
    fun saveSearch(keyword: String) { if (keyword.isBlank()) return; writableDatabase.insert("riwayat_pencarian", null, ContentValues().apply { put("keyword", keyword); put("waktu", System.currentTimeMillis()) }) }
    fun latest(): List<String> { val rows = mutableListOf<String>(); readableDatabase.rawQuery("SELECT keyword FROM riwayat_pencarian ORDER BY id DESC LIMIT 5", null).use { while (it.moveToNext()) rows.add(it.getString(0)) }; return rows }
}
