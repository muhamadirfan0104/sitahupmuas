package muhamad.irfan.sitahupm.data.model

import org.json.JSONObject

data class User(val id: Int = 0, val name: String = "", val email: String = "", val telepon: String = "") {
    companion object { fun fromJson(o: JSONObject?) = User(o?.optInt("id") ?: 0, o?.optString("name") ?: "", o?.optString("email") ?: "", o?.optString("telepon") ?: "") }
}

data class Product(val id: Int, val nama: String, val harga: Double, val stok: Int, val satuan: String, val gambar: String?, val deskripsi: String = "") {
    companion object {
        fun fromJson(o: JSONObject) = Product(o.optInt("id"), o.optString("nama"), o.optDouble("harga"), o.optInt("stok"), o.optString("satuan"), o.optString("gambar_utama").ifBlank { null }, o.optString("deskripsi"))
    }
}

data class CartItem(val id: Int, val produkId: Int, val nama: String, val harga: Double, val jumlah: Int, val subtotal: Double, val stok: Int, val gambar: String?) {
    companion object { fun fromJson(o: JSONObject) = CartItem(o.optInt("id"), o.optInt("produk_id"), o.optString("nama_produk"), o.optDouble("harga_satuan"), o.optInt("jumlah"), o.optDouble("subtotal"), o.optInt("stok_produk"), o.optString("gambar_utama").ifBlank { null }) }
}

data class OrderItem(val nama: String, val jumlah: Int, val subtotal: Double) {
    companion object { fun fromJson(o: JSONObject) = OrderItem(o.optString("nama_produk"), o.optInt("jumlah"), o.optDouble("subtotal")) }
}

data class Order(val id: Int, val invoice: String, val status: String, val statusBayar: String, val metodeAmbil: String, val metodeBayar: String, val total: Double, val qrToken: String?, val qrUrl: String?, val invoiceUrl: String?) {
    companion object {
        fun fromJson(o: JSONObject) = Order(
            o.optInt("id"), o.optString("nomor_invoice"), o.optString("status_label"), o.optString("status_pembayaran_label"),
            o.optString("metode_pengambilan_label"), o.optString("metode_pembayaran_label"), o.optDouble("total_bayar"),
            o.optString("qr_claim_token").ifBlank { null }, o.optString("qr_claim_url").ifBlank { null }, o.optString("invoice_url").ifBlank { null }
        )
    }
}

data class Address(val id: Int, val nama: String, val telepon: String, val alamat: String, val lat: Double?, val lng: Double?, val utama: Boolean) {
    companion object { fun fromJson(o: JSONObject) = Address(o.optInt("id"), o.optString("nama_penerima"), o.optString("telepon"), o.optString("alamat_lengkap"), if (o.isNull("latitude")) null else o.optDouble("latitude"), if (o.isNull("longitude")) null else o.optDouble("longitude"), o.optBoolean("utama")) }
}
