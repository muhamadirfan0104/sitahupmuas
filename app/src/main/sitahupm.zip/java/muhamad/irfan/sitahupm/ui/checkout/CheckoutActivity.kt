package muhamad.irfan.sitahupm.ui.checkout

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.model.Address
import muhamad.irfan.sitahupm.util.FormatUtil
import org.json.JSONObject
import java.util.Calendar

class CheckoutActivity: AppCompatActivity() {
    private val addresses = mutableListOf<Address>(); private var date=""; private var time=""
    override fun onCreate(b:Bundle?){ super.onCreate(b); setContentView(R.layout.activity_checkout); setupPayment(); findViewById<Button>(R.id.btnDate).setOnClickListener{pickDate()}; findViewById<Button>(R.id.btnTime).setOnClickListener{pickTime()}; findViewById<Button>(R.id.btnCheckout).setOnClickListener{checkout()}; loadCart(); loadAddress() }
    private fun setupPayment(){ val p=listOf("cod", "transfer_bank"); val auto=findViewById<AutoCompleteTextView>(R.id.autoPayment); auto.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, p)); auto.setText("cod", false) }
    private fun loadCart(){ ApiClient.request(this, Request.Method.GET, "/cart", null, { r -> val d=r.getJSONObject("data"); findViewById<TextView>(R.id.txtTotal).text="Total: ${FormatUtil.rupiah(d.optDouble("total_belanja"))}\nItem: ${d.optInt("total_item")}" }, { toast(it) }) }
    private fun loadAddress(){ ApiClient.request(this, Request.Method.GET, "/addresses", null, { r -> val a=r.getJSONArray("data"); addresses.clear(); for(i in 0 until a.length()) addresses.add(Address.fromJson(a.getJSONObject(i))); findViewById<Spinner>(R.id.spAddress).adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, addresses.map{ "${it.nama} - ${it.alamat.take(30)}" }) }, { toast(it) }) }
    private fun pickDate(){ val c=Calendar.getInstance(); DatePickerDialog(this, {_,y,m,d-> date="%04d-%02d-%02d".format(y,m+1,d); findViewById<Button>(R.id.btnDate).text=date }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }
    private fun pickTime(){ val c=Calendar.getInstance(); TimePickerDialog(this, {_,h,m-> time="%02d:%02d".format(h,m); findViewById<Button>(R.id.btnTime).text=time }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show() }
    private fun checkout(){ if(!findViewById<CheckBox>(R.id.chkSetuju).isChecked){ toast("Centang persetujuan dulu"); return }; val ambil=if(findViewById<RadioButton>(R.id.rbKurir).isChecked) "kurir_toko" else "ambil_toko"; val body=JSONObject().put("metode_pengambilan", ambil).put("metode_pembayaran", findViewById<AutoCompleteTextView>(R.id.autoPayment).text.toString()).put("setuju_pesanan", true); if(ambil=="kurir_toko" && addresses.isNotEmpty()) body.put("alamat_pengiriman_id", addresses[findViewById<Spinner>(R.id.spAddress).selectedItemPosition].id); if(date.isNotBlank()&&time.isNotBlank()){ body.put("scheduled_date", date).put("scheduled_time", time) }; ApiClient.request(this, Request.Method.POST, "/checkout", body, { toast("Pesanan berhasil dibuat"); finish() }, { toast(it) }) }
    private fun toast(m:String)=Toast.makeText(this,m,Toast.LENGTH_LONG).show()
}
