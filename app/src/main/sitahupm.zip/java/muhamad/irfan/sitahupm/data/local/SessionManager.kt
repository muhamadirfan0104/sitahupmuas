package muhamad.irfan.sitahupm.data.local

import android.content.Context

class SessionManager(context: Context) {
    private val pref = context.getSharedPreferences("sitahu_session", Context.MODE_PRIVATE)
    fun save(token: String, name: String, email: String) = pref.edit().putString("token", token).putString("name", name).putString("email", email).apply()
    fun token(): String = pref.getString("token", "") ?: ""
    fun name(): String = pref.getString("name", "Pembeli") ?: "Pembeli"
    fun email(): String = pref.getString("email", "") ?: ""
    fun isLogin(): Boolean = token().isNotBlank()
    fun clear() = pref.edit().clear().apply()
}
