package muhamad.irfan.sitahupm.ui.product

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.model.Product
import muhamad.irfan.sitahupm.util.FormatUtil

class ProductAdapter(
    private val data: MutableList<Product>,
    private val onAdd: (Product) -> Unit,
    private val onDetail: (Product) -> Unit,
    private val showLatestBadge: Boolean = true
) : RecyclerView.Adapter<ProductAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.imgProduct)
        val badge: TextView = v.findViewById(R.id.txtBadge)
        val name: TextView = v.findViewById(R.id.txtName)
        val price: TextView = v.findViewById(R.id.txtPrice)
        val stock: TextView = v.findViewById(R.id.txtStock)
        val detail: Button = v.findViewById(R.id.btnDetail)
        val add: Button = v.findViewById(R.id.btnAdd)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false))

    override fun getItemCount() = data.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = data[position]
        h.name.text = item.nama.ifBlank { "Produk SiTahu" }
        h.price.text = FormatUtil.rupiah(item.harga)
        h.stock.text = "Stok ${item.stok} ${item.satuan.ifBlank { "Pack" }}"
        h.badge.visibility = if (showLatestBadge && position < 4) View.VISIBLE else View.GONE
        ApiClient.loadImage(h.itemView.context, item.gambar, h.img)
        h.detail.setOnClickListener { onDetail(item) }
        h.add.setOnClickListener { onAdd(item) }
        h.itemView.setOnClickListener { onDetail(item) }
    }

    fun setItems(items: List<Product>) {
        data.clear()
        data.addAll(items)
        notifyDataSetChanged()
    }
}
