package muhamad.irfan.sitahupm.ui.address

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.android.volley.Request
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.model.Address
import org.json.JSONObject

class AddressActivity: AppCompatActivity() {
    override fun onCreate(b:Bundle?){ super.onCreate(b); setContentView(R.layout.activity_address); findViewById<Button>(R.id.btnGps).setOnClickListener{ getGps() }; findViewById<Button>(R.id.btnMap).setOnClickListener{ openMap() }; findViewById<Button>(R.id.btnSave).setOnClickListener{ save() }; load() }
    private fun getGps(){ if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 10); return }; val lm=getSystemService(LOCATION_SERVICE) as LocationManager; val loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); if(loc!=null){ findViewById<EditText>(R.id.edtLat).setText(loc.latitude.toString()); findViewById<EditText>(R.id.edtLng).setText(loc.longitude.toString()) } else toast("Lokasi belum tersedia, nyalakan GPS lalu coba lagi") }
    private fun openMap(){ val lat=findViewById<EditText>(R.id.edtLat).text.toString().ifBlank{"-7.8166"}; val lng=findViewById<EditText>(R.id.edtLng).text.toString().ifBlank{"112.0116"}; startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.openstreetmap.org/?mlat=$lat&mlon=$lng#map=16/$lat/$lng"))) }
    private fun save(){ val lat=findViewById<EditText>(R.id.edtLat).text.toString(); val lng=findViewById<EditText>(R.id.edtLng).text.toString(); val body=JSONObject().put("nama_penerima", findViewById<EditText>(R.id.edtNama).text.toString()).put("telepon", findViewById<EditText>(R.id.edtTelp).text.toString()).put("alamat_lengkap", findViewById<EditText>(R.id.edtAlamat).text.toString()).put("latitude", if(lat.isBlank()) JSONObject.NULL else lat).put("longitude", if(lng.isBlank()) JSONObject.NULL else lng).put("utama", findViewById<CheckBox>(R.id.chkUtama).isChecked); ApiClient.request(this, Request.Method.POST, "/addresses", body, { toast("Alamat tersimpan"); load() }, { toast(it) }) }
    private fun load(){ ApiClient.request(this, Request.Method.GET, "/addresses", null, { r -> val a=r.getJSONArray("data"); val rows= mutableListOf<String>(); for(i in 0 until a.length()){ val ad=Address.fromJson(a.getJSONObject(i)); rows.add("${ad.nama} (${if(ad.utama) "Utama" else "Alamat"})\n${ad.alamat}\n${ad.lat}, ${ad.lng}") }; findViewById<TextView>(R.id.txtList).text=rows.joinToString("\n\n") }, { toast(it) }) }
    private fun toast(m:String)=Toast.makeText(this,m,Toast.LENGTH_LONG).show()
}
