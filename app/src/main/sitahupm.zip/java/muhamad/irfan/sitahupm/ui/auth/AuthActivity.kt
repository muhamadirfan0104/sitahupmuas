package muhamad.irfan.sitahupm.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.local.SessionManager
import muhamad.irfan.sitahupm.ui.main.MainActivity
import org.json.JSONObject

class AuthActivity : AppCompatActivity() {
    private var registerMode = false
    private lateinit var name: EditText; private lateinit var phone: EditText; private lateinit var email: EditText; private lateinit var pass: EditText; private lateinit var confirm: EditText; private lateinit var btn: Button; private lateinit var switch: TextView; private lateinit var title: TextView
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.screen_auth)
        name=findViewById(R.id.edtName); phone=findViewById(R.id.edtPhone); email=findViewById(R.id.edtEmail); pass=findViewById(R.id.edtPassword); confirm=findViewById(R.id.edtPasswordConfirm); btn=findViewById(R.id.btnSubmit); switch=findViewById(R.id.txtSwitch); title=findViewById(R.id.txtAuthTitle)
        btn.setOnClickListener { submit() }; switch.setOnClickListener { registerMode=!registerMode; render() }; render()
    }
    private fun render() { name.visibility=if(registerMode) View.VISIBLE else View.GONE; phone.visibility=name.visibility; confirm.visibility=name.visibility; title.text=if(registerMode) "Daftar Akun" else "Masuk"; btn.text=if(registerMode) "Daftar" else "Login"; switch.text=if(registerMode) "Sudah punya akun? Login" else "Belum punya akun? Daftar" }
    private fun submit() {
        val body = JSONObject().put("email", email.text.toString()).put("password", pass.text.toString()).put("role", "pembeli")
        val path = if (registerMode) "/auth/register" else "/auth/login"
        if (registerMode) { body.put("name", name.text.toString()).put("telepon", phone.text.toString()).put("password_confirmation", confirm.text.toString()) }
        ApiClient.request(this, Request.Method.POST, path, body, { r ->
            val user = r.optJSONObject("user"); SessionManager(this).save(r.optString("token"), user?.optString("name") ?: "Pembeli", user?.optString("email") ?: email.text.toString())
            startActivity(Intent(this, MainActivity::class.java)); finish()
        }, { Toast.makeText(this, it, Toast.LENGTH_LONG).show() })
    }
}
