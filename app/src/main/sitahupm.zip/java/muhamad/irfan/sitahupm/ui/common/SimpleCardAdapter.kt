package muhamad.irfan.sitahupm.ui.common

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import muhamad.irfan.sitahupm.R

data class SimpleCard(val top: String, val mid: String, val bottom: String, val primary: String = "Detail", val second: String = "Aksi", val dataId: Int = 0)
class SimpleCardAdapter(private val data: MutableList<SimpleCard>, private val onPrimary: (SimpleCard) -> Unit, private val onSecond: (SimpleCard) -> Unit) : RecyclerView.Adapter<SimpleCardAdapter.VH>() {
    class VH(v: View): RecyclerView.ViewHolder(v) { val top: TextView = v.findViewById(R.id.txtTop); val mid: TextView = v.findViewById(R.id.txtMid); val bottom: TextView = v.findViewById(R.id.txtBottom); val primary: Button = v.findViewById(R.id.btnPrimary); val second: Button = v.findViewById(R.id.btnSecond) }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_simple_card, parent, false))
    override fun getItemCount() = data.size
    override fun onBindViewHolder(h: VH, p: Int) { val i = data[p]; h.top.text=i.top; h.mid.text=i.mid; h.bottom.text=i.bottom; h.primary.text=i.primary; h.second.text=i.second; h.primary.setOnClickListener{onPrimary(i)}; h.second.setOnClickListener{onSecond(i)} }
    fun setItems(items: List<SimpleCard>) { data.clear(); data.addAll(items); notifyDataSetChanged() }
}
