package muhamad.irfan.sitahupm.ui.profile

import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.view.ContextMenu
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.widget.PopupMenu
import androidx.fragment.app.Fragment
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.local.HistoryDbHelper
import muhamad.irfan.sitahupm.data.local.SessionManager
import muhamad.irfan.sitahupm.ui.address.AddressActivity
import muhamad.irfan.sitahupm.ui.auth.AuthActivity

class ProfileFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_profile, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val ctx = view.context
        val session = SessionManager(ctx)
        view.findViewById<TextView>(R.id.txtUser).text =
            "${session.name()}\n${session.email()}\n\nSession disimpan dengan SharedPreferences."

        view.findViewById<Button>(R.id.btnAddress).setOnClickListener {
            startActivity(Intent(ctx, AddressActivity::class.java))
        }
        view.findViewById<Button>(R.id.btnHistory).setOnClickListener { showHistory(view) }
        view.findViewById<Button>(R.id.btnAudio).setOnClickListener {
            ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90).startTone(ToneGenerator.TONE_PROP_BEEP, 250)
        }
        view.findViewById<Button>(R.id.btnLogout).setOnClickListener { popupLogout(it) }
        registerForContextMenu(view.findViewById(R.id.txtUser))
    }

    private fun showHistory(root: View) {
        val ctx = context ?: return
        val history = HistoryDbHelper(ctx).latest()
        root.findViewById<TextView>(R.id.txtInfo).text =
            "Riwayat pencarian SQLite:\n" + if (history.isEmpty()) "Belum ada" else history.joinToString("\n")
    }

    private fun popupLogout(anchor: View) {
        val ctx = context ?: return
        val popup = PopupMenu(ctx, anchor)
        popup.menu.add("Logout")
        popup.menu.add("Batal")
        popup.setOnMenuItemClickListener {
            if (it.title == "Logout") {
                SessionManager(ctx).clear()
                startActivity(Intent(ctx, AuthActivity::class.java))
                activity?.finish()
            }
            true
        }
        popup.show()
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menu.add("Contoh ContextMenu Profil")
    }
}
