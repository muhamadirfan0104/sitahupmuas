package muhamad.irfan.sitahupm.ui.product

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import muhamad.irfan.sitahupm.R
import muhamad.irfan.sitahupm.data.api.ApiClient
import muhamad.irfan.sitahupm.data.local.HistoryDbHelper
import muhamad.irfan.sitahupm.data.model.Product
import muhamad.irfan.sitahupm.ui.main.SearchReceiver
import org.json.JSONObject

class ProductsFragment : Fragment(), SearchReceiver {
    private lateinit var adapter: ProductAdapter
    private lateinit var empty: TextView
    private lateinit var searchTitle: TextView
    private lateinit var searchSubtitle: TextView
    private lateinit var historyText: TextView
    private var searchMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        searchMode = arguments?.getBoolean(ARG_SEARCH_MODE) == true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_products, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        empty = view.findViewById(R.id.txtEmpty)
        searchTitle = view.findViewById(R.id.txtSearchTitle)
        searchSubtitle = view.findViewById(R.id.txtSearchSubtitle)
        historyText = view.findViewById(R.id.txtHistory)

        view.findViewById<View>(R.id.normalIntro).visibility = if (searchMode) View.GONE else View.VISIBLE
        view.findViewById<View>(R.id.searchIntro).visibility = if (searchMode) View.VISIBLE else View.GONE
        view.findViewById<View>(R.id.historyCard).visibility = if (searchMode) View.VISIBLE else View.GONE
        view.findViewById<TextView>(R.id.txtClearHistory).setOnClickListener {
            val ctx = context ?: return@setOnClickListener
            HistoryDbHelper(ctx).clearHistoryCompat()
            showHistory()
        }

        adapter = ProductAdapter(
            mutableListOf(),
            onAdd = { addToCart(it) },
            onDetail = { p -> openDetail(p) },
            showLatestBadge = true
        )
        view.findViewById<RecyclerView>(R.id.rvProducts).apply {
            layoutManager = GridLayoutManager(view.context, 2)
            adapter = this@ProductsFragment.adapter
            isNestedScrollingEnabled = false
        }

        showHistory()
        if (searchMode) {
            adapter.setItems(emptyList())
            empty.visibility = View.GONE
        } else {
            load("")
        }
    }

    override fun onSearchSubmit(query: String) {
        val q = query.trim()
        if (!isAdded) return
        if (q.isBlank()) {
            searchTitle.text = "Pencarian Produk"
            searchSubtitle.text = "Ketik nama produk, lalu tekan Cari."
            adapter.setItems(emptyList())
            empty.visibility = View.GONE
            showHistory()
            return
        }
        val ctx = context ?: return
        HistoryDbHelper(ctx).saveSearch(q)
        searchTitle.text = "Hasil untuk \"$q\""
        searchSubtitle.text = "Memuat hasil pencarian dari produk web SiTahu."
        showHistory()
        load(q)
    }

    private fun load(q: String) {
        val ctx = context ?: return
        val path = "/products?per_page=30&sort=latest" + if (q.isNotBlank()) "&q=$q" else ""
        ApiClient.request(ctx, Request.Method.GET, path, null, { response ->
            if (isAdded && view != null) {
                val arr = response.getJSONObject("data").getJSONArray("data")
                val list = mutableListOf<Product>()
                for (i in 0 until arr.length()) list.add(Product.fromJson(arr.getJSONObject(i)))
                adapter.setItems(list)
                empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                if (searchMode && q.isNotBlank()) {
                    searchSubtitle.text = if (list.isEmpty()) "Produk tidak ditemukan" else "${list.size} produk ditemukan"
                }
            }
        }, {
            if (isAdded) toast(it)
        })
    }

    private fun showHistory() {
        if (!searchMode || !::historyText.isInitialized) return
        val ctx = context ?: return
        val history = HistoryDbHelper(ctx).latest()
        historyText.text = if (history.isEmpty()) "Belum ada riwayat pencarian." else history.joinToString("  •  ")
    }

    private fun addToCart(product: Product) {
        val ctx = context ?: return
        ApiClient.request(ctx, Request.Method.POST, "/cart/items", JSONObject().put("produk_id", product.id).put("jumlah", 1), {
            if (isAdded) toast("Masuk keranjang")
        }, {
            if (isAdded) toast(it)
        })
    }

    private fun openDetail(product: Product) {
        val ctx = context ?: return
        startActivity(Intent(ctx, ProductDetailActivity::class.java).putExtra("id", product.id))
    }

    private fun toast(message: String) {
        val ctx = context ?: return
        Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val ARG_SEARCH_MODE = "search_mode"
        fun newInstance(searchMode: Boolean = false) = ProductsFragment().apply {
            arguments = Bundle().apply { putBoolean(ARG_SEARCH_MODE, searchMode) }
        }
    }
}

private fun HistoryDbHelper.clearHistoryCompat() {
    writableDatabase.delete("riwayat_pencarian", null, null)
}
